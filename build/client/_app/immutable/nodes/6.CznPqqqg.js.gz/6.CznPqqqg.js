import"../chunks/Bg9kRutz.js";import"../chunks/69_IOA4Y.js";import{E as o}from"../chunks/BXTBZ4D2.js";function p(r){o(r,{boxStyles:"bg-red-400/40 dark:bg-red-500/20"})}export{p as component};
