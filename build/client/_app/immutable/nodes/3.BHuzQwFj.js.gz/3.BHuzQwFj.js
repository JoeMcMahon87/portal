import"../chunks/Bg9kRutz.js";import"../chunks/69_IOA4Y.js";import{E as o}from"../chunks/DS0R8Noo.js";function p(r){o(r,{boxStyles:"bg-red-400/20 dark:bg-red-800/10"})}export{p as component};
