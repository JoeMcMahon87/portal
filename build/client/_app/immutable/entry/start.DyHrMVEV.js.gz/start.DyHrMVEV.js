import{a as t}from"../chunks/CeEZi-qu.js";export{t as start};
